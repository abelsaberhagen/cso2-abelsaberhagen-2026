#!/usr/bin/env bash
date >> simple_runs
wc -L simple_runs
